# Installing the ML Recipe skills

Two skills: `ml-recipe` (Claude builds the notebook) and `ml-recipe-student`
(Claude mentors you while you build it). Install **both** — the student skill
cross-references the other.

They are plain Markdown instruction files with no external dependencies.

---

## Option A — one command (no Claude needed)

From the unpacked bundle directory:

```bash
mkdir -p ~/.claude/skills
cp -r skills/ml-recipe skills/ml-recipe-student ~/.claude/skills/
```

Project-scoped alternative (skills available only inside one project): copy into
`<your-project>/.claude/skills/` instead of `~/.claude/skills/`.

## Option B — let Claude install them

Open Claude Code and paste the **entire contents of `INSTALL-PROMPT.md`**. The
skill text is embedded in that file, so it works even if this bundle isn't
unpacked on disk. Claude will write the two `SKILL.md` files under
`~/.claude/skills/` and print their frontmatter back to confirm.

---

## Verify

Start a **new** Claude Code session, then:

```
/skills
```

`ml-recipe` and `ml-recipe-student` should both be listed with their
descriptions. If not:

- The directory names must be exactly `ml-recipe` and `ml-recipe-student`
  (they must match the `name:` field in each file's YAML frontmatter).
- Each directory must contain a file named `SKILL.md`.
- Restart Claude Code so it re-scans `~/.claude/skills/`.

---

## How to trigger the right skill

Naming the skill in your prompt is the most reliable trigger. Both also respond
to natural phrasing matching their description. If your Claude Code exposes
skills as slash commands, `/ml-recipe` and `/ml-recipe-student` work too.

### Have Claude build the notebook for you → `ml-recipe`

> Use the **ml-recipe** skill to build a Jupyter notebook that works the
> **\<your problem / dataset\>** supervised-learning problem end to end.

Fuller version:

> Build an end-to-end ML notebook for **\<your problem / dataset\>**, following
> Géron's Machine Learning Project Checklist. Use the **ml-recipe** skill: frame
> the problem, carve a stratified test set up front, do bivariate EDA, run the
> iterative error-analysis → feature-engineering loop in the shortlist step with
> matched hyperparameter budgets across rounds, touch the test set only once,
> and verify real executed output before writing any narrative claims.

### Be mentored through building it yourself → `ml-recipe-student`

> Use the **ml-recipe-student** skill to guide me through building an end-to-end
> ML notebook for **\<your problem / dataset\>**. Treat me as a student: I lead
> each significant decision (what to check, what to try, how to read results),
> you execute as a follower, then critique my reasoning and give your own take
> before we decide together and move on. I'm comfortable with stats and ML but
> new to this checklist as a disciplined process.

`ml-recipe-student` will **not** fire on a plain "build me a notebook" — you have
to ask to be taught / mentored / quizzed, or name it.

---

## Limitations

Built for supervised learning on **tabular**, **small-to-medium** data, in a
**Jupyter notebook**. **Binary classification** is assumed in several places
(error-analysis breakdowns, calibration, threshold reasoning, hard-voting
parity); regression and multi-class need conscious adaptation. See `README.md`
for the full table. Needs Python with `pandas`, `scikit-learn`, `seaborn`,
`scipy`, `jupyter`/`nbconvert`.
