---
name: ml-recipe
description: Build (or extend) an end-to-end ML modeling notebook following Aurélien Géron's "Machine Learning Project Checklist" (Frame → Get Data → Explore → Prepare → Shortlist Models → Fine-Tune → Present → Launch/Monitor/Maintain), with emphasis on treating error analysis as an iterative feedback loop into feature engineering rather than a final report, bivariate/interaction EDA, matched-hyperparameter-budget comparisons across feature-engineering rounds, disciplined single-touch use of the test set, and verifying real executed output before writing narrative claims. Use whenever asked to build a Jupyter/Colab notebook that works a supervised-learning problem end to end, or to add error analysis / iterative feature engineering to an existing modeling notebook.
---

# Géron's ML Recipe — Notebook Authoring

Structural and methodological guidance distilled from building a Titanic
survival-prediction notebook end to end (2026-08). The checklist itself is
well known; what this skill captures is the set of mistakes and corrections
that came out of actually doing it carefully.

## The checklist, as top-level notebook sections

Each major step is a `##` markdown section; sub-steps are `###`. Skip a
step (with a one-line note why) if it genuinely doesn't apply — don't pad
a section just to check the box.

1. Frame the problem and look at the big picture
2. Get the data
3. Explore the data to gain insights
4. Prepare the data for ML algorithms
5. Explore many different models and shortlist the best ones
6. Fine-tune your models and combine them into a great solution
7. Present your solution
8. Launch, monitor, and maintain

## EDA and error analysis are complementary, not redundant

- **EDA (Step 3) finds interactions that exist in the raw data.** For a
  small feature set (roughly ≤10 columns), do bivariate/interaction
  breakdowns — not just univariate bars — for any pair of features that
  are individually strong predictors. A `groupby([f1, f2])[target].mean()`
  crosstab is nearly free and catches conflicts a univariate plot hides
  (e.g. "Sex predicts survival" and "Pclass predicts survival" can still
  have a specific Sex×Pclass cell that breaks both univariate rules).
- **Error analysis (Step 5, "analyze the types of errors the models
  make") checks whether the *trained model* actually resolved what EDA
  found** — a model can have raw access to both interacting features and
  still fail to combine them well, especially with limited data. Do this
  with `cross_val_predict` on the **training set only**; never touch the
  test set for this, since findings are about to change the model.
- Treat these as two separate, sequential checks: EDA generates the
  hypothesis, error analysis confirms whether the model needs help with
  it. Don't skip straight to error analysis and call the interaction
  "discovered" there if a two-line crosstab in EDA would have shown it
  first, cheaper.

## The iterative loop (Step 5 is not one pass)

Géron's own checklist for "Short-List Promising Models" already says:
*"perform a quick round of feature selection and engineering... perform
one or two more quick iterations of the five previous steps."* Structure
it explicitly:

1. **Round N — quick-and-dirty comparison.** Default-hyperparameter model
   families (linear, KNN, SVM, RF, GB at minimum) via N-fold CV, on the
   current feature set.
2. **Round N error analysis.** Out-of-fold predictions on the best Round N
   model; break down errors by the subgroups/interactions EDA flagged.
   Ask what a human would use to avoid these errors, and what of that is
   actually encodable as a feature (don't force a feature engineering
   move onto every finding — some findings are honest limitations, e.g.
   "we'd need a field this dataset doesn't have").
3. **Round N+1 — feature engineering + re-run.** Add the motivated
   feature(s), re-run the *same* comparison, and **compare directly
   against Round N's table** — don't just report Round N+1's numbers in
   isolation.
4. Cap at ~2-3 rounds. Diminishing and often *mixed* returns set in fast,
   especially on small datasets (a few hundred to a few thousand rows).
   Report a round that made things worse as a genuine, useful finding —
   not something to quietly drop from the notebook.

### Two traps this loop will hit

- **Default-hyperparameter comparisons can flip sign relative to tuned
  comparisons.** A feature set that looks worse under default
  hyperparameters is not necessarily worse after tuning (and vice versa).
  Once Step 5 has shortlisted 1-2 model families, **re-tune every
  round's feature set with the same grid/budget** in Step 6 before
  deciding which round actually wins — don't let Step 5's quick-and-dirty
  ranking make that call.
- **Preprocessing/encoding choices and model-family choice aren't
  independent — this is the general case, cross features (above) are one
  instance of it.** Tree ensembles (RF, GB) can already approximate an
  interaction via sequential splits, so an explicit cross feature often
  has little to offer them; linear models can't represent an interaction
  without help, so that's the more likely place to see a payoff — but
  check empirically per model family rather than assuming either
  direction. The same logic applies to encoding an ordinal/categorical
  feature as numeric vs. one-hot: a *mechanistically sound* argument for
  why one model family should be hurt by a given encoding (e.g. a linear
  model's logit misspecifying a non-linear relationship, or a single
  numeric split being unable to isolate a middle category) still needs
  empirical checking — the real relationship may be close enough to
  linear, or unrestricted tree depth may reconstruct the "impossible"
  partition with extra splits, and the theoretically-real effect washes
  out. Test preprocessing choices **across every model family still in
  contention**, not once and then treated as settled for all of them. A
  choice that doesn't win as a standalone predictor for tree models may
  still be the thing that makes a linear model a more useful, more
  differently-wrong voter inside an ensemble (Step 6.2) — test that
  directly rather than asserting the mechanism.
- **A model's own CV standard deviation is not a valid test for
  comparing it against another model.** `cv_std` measures spread across
  that model's own folds; it says nothing about whether two models'
  *means* actually differ. Since every model in a shortlist comparison
  sees the same folds (`cv=N` with no shuffling is deterministic), use a
  **paired** comparison instead — fold-by-fold differences, e.g.
  `scipy.stats.ttest_rel` on the two score arrays — which is both more
  powerful and the statistically appropriate test. Caveat honestly: with
  only ~10 folds sharing overlapping training data, treat the resulting
  p-values as evidence, not a textbook-exact hypothesis test.

## When models tie on the primary metric, other diagnostics exist

A paired significance test finding two or more models statistically
indistinguishable on the primary metric is common on datasets this
size, not an edge case — don't just pick the higher point estimate and
move on without naming that other angles exist:

- **Log-loss / Brier score** — proper scoring rules that grade the
  predicted probability itself, not just the thresholded decision.
- **ROC-AUC** — ranking quality across all thresholds, not just the one
  the primary metric was computed at.
- **Calibration** (`sklearn.calibration.calibration_curve`) — does a
  66%-predicted bin actually contain ~66% positives? The most important
  of these to check, and a prerequisite for the next one to mean
  anything.
- **Confidence/sharpness of predicted probabilities** (e.g. a histogram
  of predicted probabilities, ideally viewed per true class rather than
  over the raw — possibly imbalanced — sample, so a skewed histogram
  isn't mistaken for genuine bimodal confidence) — but only a good sign
  *conditional on* calibration; a confidently wrong model is worse than
  an honestly uncertain one. Sharpness is a tiebreaker among comparably
  calibrated models, not a virtue standalone — an overfit model readily
  produces falsely confident probabilities.

**On tuning the decision threshold**: if a model's probabilities are
well-calibrated, threshold=0.5 is already the accuracy-maximizing choice
under 0/1 loss — this holds regardless of class imbalance. Imbalance
alone doesn't make 0.5 wrong for *accuracy* specifically; it only
matters when optimizing something else (recall, F1, a cost-weighted
objective — the same territory as class-weighting). Tuning the
threshold to chase CV accuracy specifically is mostly fitting noise on
folds already leaned on heavily elsewhere in the pipeline; treat it as
a lever for a genuinely different objective, not a free accuracy win, and
prefer fixing a bad calibration curve at its source (e.g.
`CalibratedClassifierCV`) over a threshold hack.

## Ensembling is empirical, not automatic

"Combine your best models" (Step 6) sometimes helps, sometimes doesn't —
measure the ensemble's CV score against its own components before keeping
it. A weak or highly-correlated voter can drag a soft-voting ensemble
below its best individual member.

## Standard diagnostics worth reaching for, and not forgetting to

A retrospective review of a full reference session (all 8 checklist
steps) found several standard, well-known diagnostics that were never
used despite being directly relevant to claims actually being made —
worth naming explicitly so they're not just "known to exist" but
actually reached for:

- **Learning curve** (`sklearn.model_selection.learning_curve`) — if a
  session finds itself asserting "we may be underpowered to detect a
  real effect" (a real, recurring claim in the reference session,
  always asserted from small-sample-size intuition, never checked),
  that's exactly what a learning curve tests directly: is CV score still
  climbing with more training data, or has it plateaued? Don't assert
  the underpowered-data hypothesis without checking it when the tool to
  check it directly is one import away.
- **Feature importance for an engineered feature specifically**, not
  just the model's overall ranking — when a new feature's effect comes
  back small or non-significant, check whether the model is barely
  using it (a different, more specific finding than "using it heavily
  without benefit") before concluding the feature itself doesn't
  matter.
- **Feature importance for the final chosen model**, as part of Step 7
  (Present) — a natural, standard "explain the final model" chart that
  belongs in the write-up and is easy to skip once the modeling work
  itself feels done.
- **Re-visualize a feature's distribution after imputation** — cohort-
  or group-based imputation fills many rows with a small number of
  discrete values, which can visibly distort a histogram (spikes at
  exactly those values). Sanity-check what the imputer actually did to
  the feature's shape, not just that it ran without error.

None of these are exotic — the point of listing them is that "the tool
exists" and "the tool gets used at the moment it's actually relevant"
are different things, and a session can go all the way through
Present without the second one happening even when the first is true.

## Keep the baseline in view, periodically, not just once in Step 1

Step 1's naive baselines are easy to lose sight of once deep into
modeling, tuning, and ensembling — and they're the actual point of
comparison that matters, not a formality to state once and forget.
**Resurface the current-best-vs-baseline comparison at natural
checkpoints** (end of Step 5's shortlist, after Step 6 tuning, and
especially right before the test set gets touched) rather than only in
Step 1. If the gap over the honest baseline isn't clearing — or isn't
statistically real, checked the same paired way as any other comparison
in this skill — that's a signal to question the whole approach, not
just a footnote. In the reference session this checkpoint, run right
before the test-set touch, was the one comparison all session that
actually cleared significance comfortably (a multi-point gap, p<0.01)
even though most individual modeling choices along the way couldn't
distinguish themselves from each other — worth knowing that before
committing to the irreversible step, not after.

## Test-set discipline

- **Quick look at data structure first.** Immediately after loading, run
  `.head()`, `.info()`, `.describe()` — before splitting off the test
  set. `.info()`'s non-null counts are the routine, first-line way
  missing values get noticed; don't let this step get silently dropped
  in favor of jumping straight to the split, and don't let a missing-data
  finding surface later, by accident, inside some other computation
  instead. **This step is a plausibility check, not just a missing-value
  check** — read `.describe()`'s min/max against domain constraints
  (should this column ever be negative or zero? is there a sane upper
  bound?), not only its dtype and null count. In the reference session,
  a `Fare == 0` anomaly (14 passengers, all with the same unusual
  profile — turned out to be a real, distinct subpopulation, not a data
  error) was sitting directly in `.describe()`'s own `min` column from
  the very first quick look and went unflagged until a much later,
  unrelated computation surfaced it by accident. **State the plausibility
  read explicitly, column by column**, rather than "eyeball `.describe()`
  once" — the `Fare == 0` catch was itself a lucky accident (found while
  investigating something unrelated), not the product of a systematic
  check; a retrospective review of that same session found at least one
  other column (`SibSp`/`Parch`'s upper range) that was never explicitly
  plausibility-checked at all. A vague "check plausibility" instruction
  is satisfiable by one held glance at the table; go column by column.
- Carve off the test set immediately after that (stratified split), before
  any exploration proper. Everything through Step 6.3 — EDA, error analysis,
  feature engineering rounds, hyperparameter search, ensembling — runs on
  the training set only.
- Touch the test set **exactly once**, after CV has picked a final model.
- If the test-set result is worse than the winning CV score suggested,
  **do not go back and check other tuned candidates against the test
  set** to see if one would have scored better — that's just re-running
  "touch the test set" until a number looks good, which defeats its
  purpose. Report the result, including an unflattering one, and use it
  as a teaching point about CV-vs-test variance on small datasets rather
  than explaining it away.

## A subtler leak: exploratory preprocessing reused for CV

Fitting an imputer/scaler/encoder properly *inside* a `Pipeline` and
cross-validating that pipeline is leak-safe by construction (each fold
refits on its own training portion). The leak shows up one level up: if
EDA/Prepare work happened by mutating a working DataFrame directly with
pandas (e.g. filling missing values using a statistic computed from the
*entire* training set, for convenience while exploring), and that
already-mutated DataFrame later gets fed into `cross_val_score` or
`GridSearchCV` instead of raw data routed through the real pipeline,
every CV fold's held-out portion has quietly influenced its own filled
values via the shared, full-training-set statistic — leakage entirely
contained within the training set, easy to miss because it never
touches the actual test set. The fix isn't to avoid exploring with plain
pandas (that's normal and fine for EDA) — it's discipline about the
handoff: once a transformation needs to be part of a model that gets
cross-validated, re-derive it as a proper `fit`/`transform` step and
always feed **raw** training data through the pipeline for any CV work,
never the pre-mutated exploration DataFrame.

## Implementation pitfalls (concrete, sklearn-specific)

- A custom `BaseEstimator, TransformerMixin` step inside a `Pipeline`
  (e.g. a feature-adder) does **not** automatically get
  `get_feature_names_out()` — calling it on the whole prep `Pipeline`
  raises `AttributeError`. Get feature names from the `ColumnTransformer`
  sub-step directly (`pipeline.named_steps["preprocess"].get_feature_names_out()`),
  not from the outer pipeline.
- A `VotingClassifier` (or any non-`Pipeline` final estimator) has no
  `.named_steps` at all — guard with `hasattr(model, "named_steps")`
  before assuming the final selected model is a `Pipeline`, since which
  candidate wins isn't known until the CV comparison runs.
- A custom transformer whose `fit()` sets **no** trailing-underscore
  attribute (a purely stateless transform, e.g. one that only depends on
  a constructor param) passes standalone `fit_transform()` fine, but
  `sklearn`'s `check_is_fitted()` can't recognize it as fitted once it's
  nested as the *last step of a sub-`Pipeline`* — surfaces specifically
  during `cross_val_score`/`GridSearchCV`'s `.predict()` call on held-out
  folds (`.fit()` on the training portion looks fine; the failure is
  `NotFittedError` when scoring), not during ordinary standalone testing.
  Fix: set something ending in `_` in `fit()` even for a stateless
  transformer (e.g. `self.n_features_in_ = X.shape[1]`).
- `VotingClassifier(voting="hard")` with an **even** number of
  estimators has a structural tie-break problem for binary
  classification: any disagreement is a tie, and ties resolve
  unconditionally toward the lower class label — confirmed exactly in
  the reference session (100% of disagreements between 2 estimators
  went to class 0). This isn't a neutral coin-flip; if the classes are
  imbalanced or the models already share a directional bias, it
  compounds it. Use an **odd** number of estimators for hard voting in
  binary classification, or explicitly check how ties resolve before
  trusting the result — don't assume an even-count hard vote is a fair
  compromise.

## Notebook-editing workflow (VSCode + out-of-band execution)

If editing via a notebook-cell tool and executing separately (e.g.
`jupyter nbconvert --execute --inplace`) rather than through VSCode's
live kernel: set a readable chart theme up front
(`sns.set_theme(style="whitegrid", font_scale=1.15)`, a `figure.figsize`
floor around `(10, 6)`, generous `height`/`aspect` on facet grids) —
default sizes read as cramped, caught live building the reference
notebook. And since the file changes on disk outside VSCode's own
execution, the editor doesn't always notice — mention the fix
(`Cmd/Ctrl+Shift+P` → "Revert File", or close/reopen the tab) after
pushing updates, at whatever cadence the user prefers (ask once, early).

## Process discipline: verify before narrating

The single most repeated mistake building this kind of notebook: writing
markdown commentary describing "what the results show" **before**
actually running the cell and reading the real output. This happened
twice in the reference session — once claiming a "marginal improvement"
that was actually a decrease, once asserting an unverified causal
mechanism for why an ensemble worked. The fix, applied as standard
practice:

1. Run the code first (or a scratch equivalent) and read the actual
   printed/returned numbers.
2. Write the markdown commentary to match those specific numbers —
   quote them, don't round up to a cleaner story.
3. If a claim about *why* something happened isn't directly verified by
   a cell in the notebook (e.g. "the ensemble worked because feature X
   helped the linear model specifically"), say so explicitly and hedge
   it, rather than asserting a mechanism as fact.
4. When re-executing a notebook after edits, re-check downstream markdown
   that references specific numbers — they can silently go stale.
5. Rule 3's "hedge it" isn't always enough — **when a mechanism is
   checkable, check it rather than just hedging.** Caught a second time
   in a later session: explaining a null CV result for `Pclass` encoding
   by checking whether *raw probabilities* looked linear across an
   ordinal feature, when logistic regression's actual assumption is
   linearity in the *logit* — the right scale gave a different,
   correcting answer. Same session: asserting that a sufficiently deep
   tree "could" reconstruct a partition a numeric split can't express in
   one step, without checking whether the greedy algorithm actually
   *does* — inspecting one real fitted tree's structure (`export_text`,
   `feature_importances_`) settled it directly. A mechanistically
   plausible explanation is a hypothesis like any other in this skill's
   loop, not a free pass to skip testing it.
6. This applies to offhand dismissals too, not just headline claims —
   "probably just noise, small n" is itself an assertion, and in the
   reference session it was made early on (dismissing a surprising EDA
   subgroup result) without ever being checked, while the same session's
   *later* steps held every claim to real paired significance testing.
   The discipline should be uniform from the first plot onward, not
   something that visibly tightens as a session goes on — an early
   loose dismissal that's never revisited is exactly as uncorrected as
   a late one.
