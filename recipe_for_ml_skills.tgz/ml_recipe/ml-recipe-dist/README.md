# ML Recipe Skills

Two Claude Code **skills** for building end-to-end supervised-learning notebooks
following Aurélien Géron's *Machine Learning Project Checklist*:

| Skill | Mode |
|---|---|
| `ml-recipe` | Claude builds the notebook end to end. |
| `ml-recipe-student` | Socratic mentor mode — **you** lead every significant decision, Claude executes and critiques. |

Both distil the mistakes-and-corrections from a real reference session (a Titanic
survival model, Aug 2026). Titanic is only the reference case; the guidance is
general — see **Limitations** below for the band it actually covers.

---

## What's in this bundle

```
ml-recipe-dist/
  README.md              this file
  INSTALL.md             step-by-step install + trigger prompts
  INSTALL-PROMPT.md      self-contained — paste into Claude Code to auto-install
  BUILD-INFO.txt         build date + SHA-256 of each SKILL.md
  skills/
    ml-recipe/SKILL.md
    ml-recipe-student/SKILL.md
```

The two `SKILL.md` files are the entire product. They have **no** external
dependencies: no helper scripts, no asset files, no reliance on other skills,
MCP servers, or any `CLAUDE.md` content. `ml-recipe-student` cross-references
`ml-recipe` by name, so install **both**.

See **INSTALL.md** to install.

---

## Limitations / assumptions

Built for **supervised learning on tabular data, small-to-medium size**
(hundreds to low tens of thousands of rows), in a **Jupyter/Colab notebook**.
Within that band the guidance is general. Outside it, adapt consciously:

| Assumption | What to change outside it |
|---|---|
| **Binary classification** | FN-vs-FP error analysis, calibration curves, log-loss, threshold=0.5 reasoning, and even-count hard-voting parity are binary-specific. Regression → residual analysis / RMSE / quantile calibration. Multi-class → per-class confusion, one-vs-rest AUC. The loop *structure* still holds. |
| **Small feature set (≤ ~10 columns)** | "bivariate crosstab for every strong pair" and column-by-column plausibility checks don't scale to 100+ features — switch to importance-guided interaction checks. |
| **Small n (~hundreds–thousands of rows)** | The ~10-fold paired-t-test framing, "underpowered to detect an effect," and diminishing-returns-after-2-rounds assume scarce data. With large n, use a real validation holdout and much of that eases. |
| **Tabular / scikit-learn** | Assumes the `Pipeline` / `ColumnTransformer` idiom throughout. Not for text, images, time series, unsupervised, or deep learning. |
| **Edit-on-disk + `nbconvert` execution** | Some "session mechanics" bullets (force-refreshing stale VSCode output, switching to `nbformat` when notebook edits hit a size limit) assume the notebook is edited on disk and run via `jupyter nbconvert --execute --inplace`, not a live kernel or Colab. Those bullets simply don't apply if you work differently. |
| **Student profile** (`ml-recipe-student` only) | Calibrated for someone strong in stats/ML/code but new to the *checklist as a process*. Recalibrate deliberately for a genuinely stats-new student. |

**Environment needs:** Python with `pandas`, `scikit-learn`, `seaborn`, `scipy`,
and `jupyter` / `nbconvert`.
