# Paste this entire message into Claude Code to install the ML Recipe skills

You are being asked to install two Claude Code skills on this machine.

Do the following:

1. Create the directory `~/.claude/skills/ml-recipe/` and write its `SKILL.md`
   with the exact content in the block labelled
   `FILE: ~/.claude/skills/ml-recipe/SKILL.md` below (everything between its
   BEGIN and END markers, verbatim — do not reformat, re-wrap, or "improve" it).
2. Create the directory `~/.claude/skills/ml-recipe-student/` and write its
   `SKILL.md` from the block labelled
   `FILE: ~/.claude/skills/ml-recipe-student/SKILL.md` the same way.
3. Confirm both files exist and print the first 5 lines of each so I can see the
   YAML frontmatter (`name:` must be `ml-recipe` and `ml-recipe-student`
   respectively, matching their directory names).
4. Tell me to restart Claude Code / start a new session, then run `/skills` to
   confirm both are picked up.

Do not execute anything else. These are Markdown instruction files only.

After install, here is how I trigger them:

- To have you BUILD a notebook for me:
  "Use the ml-recipe skill to build a Jupyter notebook that works the <X>
  supervised-learning problem end to end."

- To be MENTORED through building one myself:
  "Use the ml-recipe-student skill to guide me through an end-to-end ML notebook
  for <X>. Treat me as a student: I lead each significant decision, you execute
  and then critique, we decide together before moving on."

These skills assume supervised learning on tabular data, small-to-medium size,
in a Jupyter notebook. Binary classification is assumed in several places
(error-analysis breakdowns, calibration, threshold reasoning, hard-voting
parity); regression / multi-class need conscious adaptation. Needs Python with
pandas, scikit-learn, seaborn, scipy, jupyter/nbconvert.

---

===== BEGIN FILE: ~/.claude/skills/ml-recipe/SKILL.md =====
---
name: ml-recipe
description: Build (or extend) an end-to-end ML modeling notebook following Aurélien Géron's "Machine Learning Project Checklist" (Frame → Get Data → Explore → Prepare → Shortlist Models → Fine-Tune → Present → Launch/Monitor/Maintain), with emphasis on treating error analysis as an iterative feedback loop into feature engineering rather than a final report, bivariate/interaction EDA, matched-hyperparameter-budget comparisons across feature-engineering rounds, disciplined single-touch use of the test set, and verifying real executed output before writing narrative claims. Use whenever asked to build a Jupyter/Colab notebook that works a supervised-learning problem end to end, or to add error analysis / iterative feature engineering to an existing modeling notebook.
---

# Géron's ML Recipe — Notebook Authoring

Structural and methodological guidance distilled from building a Titanic
survival-prediction notebook end to end (2026-08). The checklist itself is
well known; what this skill captures is the set of mistakes and corrections
that came out of actually doing it carefully.

## The checklist, as top-level notebook sections

Each major step is a `##` markdown section; sub-steps are `###`. Skip a
step (with a one-line note why) if it genuinely doesn't apply — don't pad
a section just to check the box.

1. Frame the problem and look at the big picture
2. Get the data
3. Explore the data to gain insights
4. Prepare the data for ML algorithms
5. Explore many different models and shortlist the best ones
6. Fine-tune your models and combine them into a great solution
7. Present your solution
8. Launch, monitor, and maintain

## EDA and error analysis are complementary, not redundant

- **EDA (Step 3) finds interactions that exist in the raw data.** For a
  small feature set (roughly ≤10 columns), do bivariate/interaction
  breakdowns — not just univariate bars — for any pair of features that
  are individually strong predictors. A `groupby([f1, f2])[target].mean()`
  crosstab is nearly free and catches conflicts a univariate plot hides
  (e.g. "Sex predicts survival" and "Pclass predicts survival" can still
  have a specific Sex×Pclass cell that breaks both univariate rules).
- **Error analysis (Step 5, "analyze the types of errors the models
  make") checks whether the *trained model* actually resolved what EDA
  found** — a model can have raw access to both interacting features and
  still fail to combine them well, especially with limited data. Do this
  with `cross_val_predict` on the **training set only**; never touch the
  test set for this, since findings are about to change the model.
- Treat these as two separate, sequential checks: EDA generates the
  hypothesis, error analysis confirms whether the model needs help with
  it. Don't skip straight to error analysis and call the interaction
  "discovered" there if a two-line crosstab in EDA would have shown it
  first, cheaper.

## The iterative loop (Step 5 is not one pass)

Géron's own checklist for "Short-List Promising Models" already says:
*"perform a quick round of feature selection and engineering... perform
one or two more quick iterations of the five previous steps."* Structure
it explicitly:

1. **Round N — quick-and-dirty comparison.** Default-hyperparameter model
   families (linear, KNN, SVM, RF, GB at minimum) via N-fold CV, on the
   current feature set.
2. **Round N error analysis.** Out-of-fold predictions on the best Round N
   model; break down errors by the subgroups/interactions EDA flagged.
   Ask what a human would use to avoid these errors, and what of that is
   actually encodable as a feature (don't force a feature engineering
   move onto every finding — some findings are honest limitations, e.g.
   "we'd need a field this dataset doesn't have").
3. **Round N+1 — feature engineering + re-run.** Add the motivated
   feature(s), re-run the *same* comparison, and **compare directly
   against Round N's table** — don't just report Round N+1's numbers in
   isolation.
4. Cap at ~2-3 rounds. Diminishing and often *mixed* returns set in fast,
   especially on small datasets (a few hundred to a few thousand rows).
   Report a round that made things worse as a genuine, useful finding —
   not something to quietly drop from the notebook.

### Two traps this loop will hit

- **Default-hyperparameter comparisons can flip sign relative to tuned
  comparisons.** A feature set that looks worse under default
  hyperparameters is not necessarily worse after tuning (and vice versa).
  Once Step 5 has shortlisted 1-2 model families, **re-tune every
  round's feature set with the same grid/budget** in Step 6 before
  deciding which round actually wins — don't let Step 5's quick-and-dirty
  ranking make that call.
- **Preprocessing/encoding choices and model-family choice aren't
  independent — this is the general case, cross features (above) are one
  instance of it.** Tree ensembles (RF, GB) can already approximate an
  interaction via sequential splits, so an explicit cross feature often
  has little to offer them; linear models can't represent an interaction
  without help, so that's the more likely place to see a payoff — but
  check empirically per model family rather than assuming either
  direction. The same logic applies to encoding an ordinal/categorical
  feature as numeric vs. one-hot: a *mechanistically sound* argument for
  why one model family should be hurt by a given encoding (e.g. a linear
  model's logit misspecifying a non-linear relationship, or a single
  numeric split being unable to isolate a middle category) still needs
  empirical checking — the real relationship may be close enough to
  linear, or unrestricted tree depth may reconstruct the "impossible"
  partition with extra splits, and the theoretically-real effect washes
  out. Test preprocessing choices **across every model family still in
  contention**, not once and then treated as settled for all of them. A
  choice that doesn't win as a standalone predictor for tree models may
  still be the thing that makes a linear model a more useful, more
  differently-wrong voter inside an ensemble (Step 6.2) — test that
  directly rather than asserting the mechanism.
- **A model's own CV standard deviation is not a valid test for
  comparing it against another model.** `cv_std` measures spread across
  that model's own folds; it says nothing about whether two models'
  *means* actually differ. Since every model in a shortlist comparison
  sees the same folds (`cv=N` with no shuffling is deterministic), use a
  **paired** comparison instead — fold-by-fold differences, e.g.
  `scipy.stats.ttest_rel` on the two score arrays — which is both more
  powerful and the statistically appropriate test. Caveat honestly: with
  only ~10 folds sharing overlapping training data, treat the resulting
  p-values as evidence, not a textbook-exact hypothesis test.

## When models tie on the primary metric, other diagnostics exist

A paired significance test finding two or more models statistically
indistinguishable on the primary metric is common on datasets this
size, not an edge case — don't just pick the higher point estimate and
move on without naming that other angles exist:

- **Log-loss / Brier score** — proper scoring rules that grade the
  predicted probability itself, not just the thresholded decision.
- **ROC-AUC** — ranking quality across all thresholds, not just the one
  the primary metric was computed at.
- **Calibration** (`sklearn.calibration.calibration_curve`) — does a
  66%-predicted bin actually contain ~66% positives? The most important
  of these to check, and a prerequisite for the next one to mean
  anything.
- **Confidence/sharpness of predicted probabilities** (e.g. a histogram
  of predicted probabilities, ideally viewed per true class rather than
  over the raw — possibly imbalanced — sample, so a skewed histogram
  isn't mistaken for genuine bimodal confidence) — but only a good sign
  *conditional on* calibration; a confidently wrong model is worse than
  an honestly uncertain one. Sharpness is a tiebreaker among comparably
  calibrated models, not a virtue standalone — an overfit model readily
  produces falsely confident probabilities.

**On tuning the decision threshold**: if a model's probabilities are
well-calibrated, threshold=0.5 is already the accuracy-maximizing choice
under 0/1 loss — this holds regardless of class imbalance. Imbalance
alone doesn't make 0.5 wrong for *accuracy* specifically; it only
matters when optimizing something else (recall, F1, a cost-weighted
objective — the same territory as class-weighting). Tuning the
threshold to chase CV accuracy specifically is mostly fitting noise on
folds already leaned on heavily elsewhere in the pipeline; treat it as
a lever for a genuinely different objective, not a free accuracy win, and
prefer fixing a bad calibration curve at its source (e.g.
`CalibratedClassifierCV`) over a threshold hack.

## Ensembling is empirical, not automatic

"Combine your best models" (Step 6) sometimes helps, sometimes doesn't —
measure the ensemble's CV score against its own components before keeping
it. A weak or highly-correlated voter can drag a soft-voting ensemble
below its best individual member.

## Standard diagnostics worth reaching for, and not forgetting to

A retrospective review of a full reference session (all 8 checklist
steps) found several standard, well-known diagnostics that were never
used despite being directly relevant to claims actually being made —
worth naming explicitly so they're not just "known to exist" but
actually reached for:

- **Learning curve** (`sklearn.model_selection.learning_curve`) — if a
  session finds itself asserting "we may be underpowered to detect a
  real effect" (a real, recurring claim in the reference session,
  always asserted from small-sample-size intuition, never checked),
  that's exactly what a learning curve tests directly: is CV score still
  climbing with more training data, or has it plateaued? Don't assert
  the underpowered-data hypothesis without checking it when the tool to
  check it directly is one import away.
- **Feature importance for an engineered feature specifically**, not
  just the model's overall ranking — when a new feature's effect comes
  back small or non-significant, check whether the model is barely
  using it (a different, more specific finding than "using it heavily
  without benefit") before concluding the feature itself doesn't
  matter.
- **Feature importance for the final chosen model**, as part of Step 7
  (Present) — a natural, standard "explain the final model" chart that
  belongs in the write-up and is easy to skip once the modeling work
  itself feels done.
- **Re-visualize a feature's distribution after imputation** — cohort-
  or group-based imputation fills many rows with a small number of
  discrete values, which can visibly distort a histogram (spikes at
  exactly those values). Sanity-check what the imputer actually did to
  the feature's shape, not just that it ran without error.

None of these are exotic — the point of listing them is that "the tool
exists" and "the tool gets used at the moment it's actually relevant"
are different things, and a session can go all the way through
Present without the second one happening even when the first is true.

## Keep the baseline in view, periodically, not just once in Step 1

Step 1's naive baselines are easy to lose sight of once deep into
modeling, tuning, and ensembling — and they're the actual point of
comparison that matters, not a formality to state once and forget.
**Resurface the current-best-vs-baseline comparison at natural
checkpoints** (end of Step 5's shortlist, after Step 6 tuning, and
especially right before the test set gets touched) rather than only in
Step 1. If the gap over the honest baseline isn't clearing — or isn't
statistically real, checked the same paired way as any other comparison
in this skill — that's a signal to question the whole approach, not
just a footnote. In the reference session this checkpoint, run right
before the test-set touch, was the one comparison all session that
actually cleared significance comfortably (a multi-point gap, p<0.01)
even though most individual modeling choices along the way couldn't
distinguish themselves from each other — worth knowing that before
committing to the irreversible step, not after.

## Test-set discipline

- **Quick look at data structure first.** Immediately after loading, run
  `.head()`, `.info()`, `.describe()` — before splitting off the test
  set. `.info()`'s non-null counts are the routine, first-line way
  missing values get noticed; don't let this step get silently dropped
  in favor of jumping straight to the split, and don't let a missing-data
  finding surface later, by accident, inside some other computation
  instead. **This step is a plausibility check, not just a missing-value
  check** — read `.describe()`'s min/max against domain constraints
  (should this column ever be negative or zero? is there a sane upper
  bound?), not only its dtype and null count. In the reference session,
  a `Fare == 0` anomaly (14 passengers, all with the same unusual
  profile — turned out to be a real, distinct subpopulation, not a data
  error) was sitting directly in `.describe()`'s own `min` column from
  the very first quick look and went unflagged until a much later,
  unrelated computation surfaced it by accident. **State the plausibility
  read explicitly, column by column**, rather than "eyeball `.describe()`
  once" — the `Fare == 0` catch was itself a lucky accident (found while
  investigating something unrelated), not the product of a systematic
  check; a retrospective review of that same session found at least one
  other column (`SibSp`/`Parch`'s upper range) that was never explicitly
  plausibility-checked at all. A vague "check plausibility" instruction
  is satisfiable by one held glance at the table; go column by column.
- Carve off the test set immediately after that (stratified split), before
  any exploration proper. Everything through Step 6.3 — EDA, error analysis,
  feature engineering rounds, hyperparameter search, ensembling — runs on
  the training set only.
- Touch the test set **exactly once**, after CV has picked a final model.
- If the test-set result is worse than the winning CV score suggested,
  **do not go back and check other tuned candidates against the test
  set** to see if one would have scored better — that's just re-running
  "touch the test set" until a number looks good, which defeats its
  purpose. Report the result, including an unflattering one, and use it
  as a teaching point about CV-vs-test variance on small datasets rather
  than explaining it away.

## A subtler leak: exploratory preprocessing reused for CV

Fitting an imputer/scaler/encoder properly *inside* a `Pipeline` and
cross-validating that pipeline is leak-safe by construction (each fold
refits on its own training portion). The leak shows up one level up: if
EDA/Prepare work happened by mutating a working DataFrame directly with
pandas (e.g. filling missing values using a statistic computed from the
*entire* training set, for convenience while exploring), and that
already-mutated DataFrame later gets fed into `cross_val_score` or
`GridSearchCV` instead of raw data routed through the real pipeline,
every CV fold's held-out portion has quietly influenced its own filled
values via the shared, full-training-set statistic — leakage entirely
contained within the training set, easy to miss because it never
touches the actual test set. The fix isn't to avoid exploring with plain
pandas (that's normal and fine for EDA) — it's discipline about the
handoff: once a transformation needs to be part of a model that gets
cross-validated, re-derive it as a proper `fit`/`transform` step and
always feed **raw** training data through the pipeline for any CV work,
never the pre-mutated exploration DataFrame.

## Implementation pitfalls (concrete, sklearn-specific)

- A custom `BaseEstimator, TransformerMixin` step inside a `Pipeline`
  (e.g. a feature-adder) does **not** automatically get
  `get_feature_names_out()` — calling it on the whole prep `Pipeline`
  raises `AttributeError`. Get feature names from the `ColumnTransformer`
  sub-step directly (`pipeline.named_steps["preprocess"].get_feature_names_out()`),
  not from the outer pipeline.
- A `VotingClassifier` (or any non-`Pipeline` final estimator) has no
  `.named_steps` at all — guard with `hasattr(model, "named_steps")`
  before assuming the final selected model is a `Pipeline`, since which
  candidate wins isn't known until the CV comparison runs.
- A custom transformer whose `fit()` sets **no** trailing-underscore
  attribute (a purely stateless transform, e.g. one that only depends on
  a constructor param) passes standalone `fit_transform()` fine, but
  `sklearn`'s `check_is_fitted()` can't recognize it as fitted once it's
  nested as the *last step of a sub-`Pipeline`* — surfaces specifically
  during `cross_val_score`/`GridSearchCV`'s `.predict()` call on held-out
  folds (`.fit()` on the training portion looks fine; the failure is
  `NotFittedError` when scoring), not during ordinary standalone testing.
  Fix: set something ending in `_` in `fit()` even for a stateless
  transformer (e.g. `self.n_features_in_ = X.shape[1]`).
- `VotingClassifier(voting="hard")` with an **even** number of
  estimators has a structural tie-break problem for binary
  classification: any disagreement is a tie, and ties resolve
  unconditionally toward the lower class label — confirmed exactly in
  the reference session (100% of disagreements between 2 estimators
  went to class 0). This isn't a neutral coin-flip; if the classes are
  imbalanced or the models already share a directional bias, it
  compounds it. Use an **odd** number of estimators for hard voting in
  binary classification, or explicitly check how ties resolve before
  trusting the result — don't assume an even-count hard vote is a fair
  compromise.

## Notebook-editing workflow (VSCode + out-of-band execution)

If editing via a notebook-cell tool and executing separately (e.g.
`jupyter nbconvert --execute --inplace`) rather than through VSCode's
live kernel: set a readable chart theme up front
(`sns.set_theme(style="whitegrid", font_scale=1.15)`, a `figure.figsize`
floor around `(10, 6)`, generous `height`/`aspect` on facet grids) —
default sizes read as cramped, caught live building the reference
notebook. And since the file changes on disk outside VSCode's own
execution, the editor doesn't always notice — mention the fix
(`Cmd/Ctrl+Shift+P` → "Revert File", or close/reopen the tab) after
pushing updates, at whatever cadence the user prefers (ask once, early).

## Process discipline: verify before narrating

The single most repeated mistake building this kind of notebook: writing
markdown commentary describing "what the results show" **before**
actually running the cell and reading the real output. This happened
twice in the reference session — once claiming a "marginal improvement"
that was actually a decrease, once asserting an unverified causal
mechanism for why an ensemble worked. The fix, applied as standard
practice:

1. Run the code first (or a scratch equivalent) and read the actual
   printed/returned numbers.
2. Write the markdown commentary to match those specific numbers —
   quote them, don't round up to a cleaner story.
3. If a claim about *why* something happened isn't directly verified by
   a cell in the notebook (e.g. "the ensemble worked because feature X
   helped the linear model specifically"), say so explicitly and hedge
   it, rather than asserting a mechanism as fact.
4. When re-executing a notebook after edits, re-check downstream markdown
   that references specific numbers — they can silently go stale.
5. Rule 3's "hedge it" isn't always enough — **when a mechanism is
   checkable, check it rather than just hedging.** Caught a second time
   in a later session: explaining a null CV result for `Pclass` encoding
   by checking whether *raw probabilities* looked linear across an
   ordinal feature, when logistic regression's actual assumption is
   linearity in the *logit* — the right scale gave a different,
   correcting answer. Same session: asserting that a sufficiently deep
   tree "could" reconstruct a partition a numeric split can't express in
   one step, without checking whether the greedy algorithm actually
   *does* — inspecting one real fitted tree's structure (`export_text`,
   `feature_importances_`) settled it directly. A mechanistically
   plausible explanation is a hypothesis like any other in this skill's
   loop, not a free pass to skip testing it.
6. This applies to offhand dismissals too, not just headline claims —
   "probably just noise, small n" is itself an assertion, and in the
   reference session it was made early on (dismissing a surprising EDA
   subgroup result) without ever being checked, while the same session's
   *later* steps held every claim to real paired significance testing.
   The discipline should be uniform from the first plot onward, not
   something that visibly tightens as a session goes on — an early
   loose dismissal that's never revisited is exactly as uncorrected as
   a late one.
===== END FILE: ~/.claude/skills/ml-recipe/SKILL.md =====

===== BEGIN FILE: ~/.claude/skills/ml-recipe-student/SKILL.md =====
---
name: ml-recipe-student
description: Guide a STUDENT through an end-to-end ML modeling notebook following Géron's Machine Learning Project Checklist, in Socratic/mentor mode rather than doing the work autonomously — the student leads each significant step (proposes what to check, what to try, how to interpret results) and Claude executes as a follower (writes code, runs experiments, shows charts), then critiques the student's reasoning, offers its own take, and the two jointly decide how to proceed before advancing. Trivial/mechanical steps (loading data, boilerplate splits) are just done without ceremony. The goal is training the student's instinct for WHAT to ask/decide at each step, not just producing a good notebook. Use when the user explicitly asks to be treated as a student, to be taught/mentored/quizzed through a modeling notebook, or names this skill — not for ordinary "build me a notebook" requests (use the `ml-recipe` skill for those).
---

# Géron's ML Recipe — Student / Mentor Mode

Same checklist and same technical bar as the `ml-recipe` skill (bivariate
EDA, iterative error-analysis loop, matched-hyperparameter-budget
comparisons across rounds, disciplined single-touch test set, verify
real output before narrating). **This skill changes who leads.** In
`ml-recipe`, Claude drives end to end. Here, the student drives every
significant decision; Claude executes, then mentors.

State the meta-goal once, near the start of the session, in plain terms:
this isn't a quiz to pass — it's practice at the skill of directing an
AI-assisted ML workflow: knowing what to check, what to ask for, and how
to judge what comes back. That's what should transfer once Claude isn't
in the room.

## Default student profile: sophisticated, but a Recipe novice

Absent signals otherwise, calibrate for **a technically strong
student (comfortable with statistics, ML concepts, code) who is new
specifically to *this methodology* — the checklist as a disciplined,
sequenced process** — not new to the underlying math or stats. This
came directly from the author of this skill self-assessing after a full
reference session: "smart, background in statistics, novice to the
Recipe" — and asking to shade toward *more* guidance, but of a specific
kind. That distinction matters and should shape *what kind* of extra
guidance gets added, not just "explain more":

- **Terse on statistical/technical content.** Don't add hand-holding on
  what a p-value, phi coefficient, or calibration curve *is* — this
  profile grasps that immediately, confirmed repeatedly in the
  reference session (calibration, log-loss, tie-breaking mechanics all
  engaged with precisely on first mention).
- **More explicit on process/sequencing logic — why this step, why now,
  what the checklist's own philosophy implies comes next.** *This* is
  the actually-novel material for this profile. Protocol step 1
  ("frame it") is the mechanism for this and should not be treated as
  skippable or reducible to one throwaway sentence, especially as a
  session gets longer and more technical-feeling (see the protocol-drift
  note under step 5) — a stats-sophisticated student won't need help
  forming a hypothesis about *what to check*, but may genuinely not yet
  have the instinct for *where a given question belongs in the recipe's
  sequence*, or *why deferring a decision now versus deciding immediately*
  is itself a checklist-consistent move.
- **Lean toward narrating sequencing/meta-process decisions explicitly**
  (why quick-checks-then-full-tuning, why ensembling waits until last,
  why a baseline gets re-checked before an irreversible step) even where
  the *execution* itself is mechanical enough to just do — the transfer
  goal is the recipe's sequencing discipline, and that's exactly the
  layer this profile is still building intuition for.

If actually working with a different student profile (e.g. genuinely
new to statistics, or already fluent in this exact checklist
methodology from prior use), recalibrate deliberately rather than
defaulting to this — this is a starting assumption grounded in one
real session, not a fixed rule.

## Classifying steps: prompt vs. just do it

Before each checklist step, decide which mode it gets. Default to
prompting — mechanical execution is the exception, not the norm.

**Prompt the student first (most of the checklist):**
- Step 1 (Frame the problem): objective, framing, performance measure,
  what a naive baseline should be.
- Step 3 (Explore): what to look at and why, what hypotheses to test,
  which plots would actually be informative versus just busywork.
- Step 4 (Prepare): what to impute and how, what features to engineer
  and what motivates them.
- Step 5 (Shortlist + iterate): which model families to try, how to read
  an error-analysis table, what feature change a given error pattern
  actually motivates (or doesn't). **If a preprocessing/encoding
  decision is still open when model shortlisting starts (e.g. numeric
  vs. one-hot for an ordinal feature), flag explicitly that model choice
  and encoding choice may not be independent** — different model
  families can have different sensitivity to the same encoding (a linear
  model's logit vs. a tree's split structure, for instance) — so it may
  be worth testing the two jointly (a small model × encoding grid) rather
  than resolving one and then the other in sequence.
- Step 6 (Fine-tune): what to tune, whether an ensemble is worth trying,
  what criterion picks the final model.
- Step 7 (Present): what the summary should say, what limitations matter.

**Just do it, with a one-line note of what/why (no ceremony):**
- Imports, environment setup, plotting boilerplate.
- Loading the dataset and the mechanical parts of Step 2 (though the
  *decision* to carve a stratified test set now, and never touch it
  until the end, is worth one short sentence of why — state it, don't
  interrogate the student on it).
- **The quick look at data structure — `.head()`, `.info()`,
  `.describe()` — runs immediately after loading, before the split, every
  time. This is routine orientation, not a judgment call, so don't ask
  permission to run it.** But don't narrate what it shows either: display
  the raw output and ask the student what stands out (missing values,
  odd dtypes, an unexpected range) before saying anything yourself — this
  is the natural first "ask, don't tell" checkpoint, and it's easy to
  skip past silently since running the cell itself needs no prompting.
  (Concretely: this step got dropped once in the reference session,
  and the missing-`Age` finding only surfaced by accident later, inside
  a baseline computation, without ever asking the student to read
  `.info()`'s output themselves — don't repeat that.)
- **The quick look is a plausibility check, not just a missing-value
  check** — `.describe()`'s min/max against domain constraints (should
  this ever be negative or zero? is there a sane upper bound?) deserves
  the same "what stands out" prompt as the missing-value counts, same
  cell, same moment. Concretely: a `Fare == 0` anomaly (14 passengers,
  one unusual shared profile) was sitting in `.describe()`'s own `min`
  column from the very first quick look in the reference session and
  wasn't caught until a much later, unrelated computation surfaced it by
  accident — the student caught the gap in the process, not Claude. That
  catch was itself lucky (found while checking something unrelated), not
  systematic — prompt for a plausibility read **column by column**, not
  one held glance at the whole table; a later retrospective found at
  least one other column in that same session that was never explicitly
  checked at all.
- Re-running something the student already decided on (see protocol
  below — once direction is set, execution doesn't get re-litigated).
- Step 8 (Launch/monitor) when it's mostly "not applicable" — discuss
  briefly, don't manufacture a decision point that isn't there.

Use judgment at the margins. If a "mechanical" step actually has a
non-obvious choice buried in it (e.g. *why* stratify the split, *why* now
and not after EDA), a single sentence of explanation is often enough —
it doesn't need the full protocol below.

## Protocol for a significant step

A useful lens for *how you phrase step 2's prompt*: where it fits
naturally, nudge the student toward a testable hypothesis rather than
just a direction — "formulate a hypothesis → test it → examine the
results → discuss → decide" gives their proposal somewhere concrete to
land, and makes step 5/6 (show the result, examine, decide) fall out
naturally. This is a **coaching technique to apply with judgment, not a
requirement every significant step must satisfy** — some things
genuinely aren't hypothesis-shaped (open-ended exploration, a design
choice with no single measurable test). Same category as the CV-leak
note below: a teaching moment to surface when it fits, not a gate that
blocks the student from proceeding.

1. **Frame it.** Name the checklist step and, in a sentence or two,
   what it's generally for — don't assume the student has the checklist
   memorized.
2. **Ask, don't tell.** Pose an open question that requires reasoning,
   not recall. Prefer "What would you check first, and why do you think
   it matters for this problem?" over "Should we check X or Y?" — the
   point is generating the idea, not picking from a menu. Where it fits
   naturally, nudge toward a *testable hypothesis* specifically ("women
   and children survive more" is a claim you can check; "let's explore"
   isn't yet one) — a prompting technique, not a requirement every answer
   must satisfy. Reserve multiple-choice-style prompts (e.g.
   `AskUserQuestion`) for genuinely narrow, concrete decisions (e.g.
   choosing between two already-proposed
   modeling approaches), not for open-ended "what should we explore."
3. **Wait.** Do not do the work yet, and do not supply the answer
   preemptively — including in the framing of the question itself.
4. **Respond to what's actually given.**
   - A concrete, reasonable proposal → execute it as a follower: write
     the code, run it, produce the chart/table that actually tests the
     hypothesis. Don't second-guess the direction before trying it.
   - A shallow or incomplete answer → one Socratic follow-up nudge, not
     a lecture. ("That would tell us X — what about Y, does that change
     anything?")
   - "I don't know" or a genuine stall → offer a smaller scaffold hint
     (narrow the question, not the answer), then wait again.
5. **Show the result, then ask for the read.** Before offering your own
   interpretation, ask what the student notices or concludes from it.
   **This step visibly decays over a long session** — a full-length
   reference session followed it closely through the early checklist
   steps, then drifted into presenting a result and Claude's own
   reading in the same breath once the work turned more technical
   (deep into Step 6's tuning/calibration/ensemble results), skipping
   the pause. Technical-feeling results are not an exception to this
   step — recalibrate deliberately at each new sub-step rather than
   letting protocol rigor quietly decay as pace picks up.
6. **Critique, then offer your own take.** Say plainly what the
   student's reasoning got right and what it missed, whether you'd have
   prioritized something else and why, and — if relevant — what the
   `ml-recipe` skill's technical bar would call for here (e.g. "this is
   the point where matched-budget tuning across rounds matters, not just
   a default-hyperparameter comparison"). Be direct; a mentor who only
   praises isn't useful. **This cuts both ways** — when the student
   pushes back on *your* explanation (not just their own hypothesis),
   check it with the same rigor rather than defending it, and actually
   test it if it's checkable (see `ml-recipe`'s "verify before
   narrating," rule 5). A caught-and-corrected mistake in the mentor's
   own reasoning, shown openly, is a more honest demonstration of the
   practice than never being wrong.
7. **Decide together, then move on — and write the decision down.** Land
   on accept / revise / explore further explicitly before advancing to
   the next checklist step — don't just silently proceed with Claude's
   preferred version. **Every non-trivial decision gets its own markdown
   cell in the notebook, at the point it's made**, capturing the
   hypothesis, what was actually found, and why the decision came out
   the way it did — not just the resulting code. The notebook should
   read as a record of *how* conclusions were reached, not only what
   they were; a reader skimming markdown-only should be able to
   reconstruct the reasoning without needing the original chat. A
   running tracker like "Ideas to Revisit" is a supplement to this, not
   a substitute for it — decisions belong in the step where they're
   made, not only summarized later in a log.

## What "follower" doing-the-work looks like

Once direction is set (by the student, or jointly after critique),
execute fully and competently — write real code, actually run it, read
the real output before writing any commentary about it (same discipline
as `ml-recipe`), produce real charts. Being a follower on *direction*
doesn't mean being sloppy on *execution* — the student should see
competent, honest execution of their idea, including when it doesn't pan
out. A finding that contradicts the student's hypothesis is exactly the
kind of result worth sitting with, not smoothing over.

## Quantitative comparisons need to be seen, not narrated

This started as an error-analysis-specific rule and had to be widened
after it didn't generalize on its own: **default to actually
visualizing a quantitative comparison — any of them — rather than
narrating it from printed tables or dict output.** Concretely, this
went wrong twice in the reference session, at two different steps, and
the second time was a relapse of a lesson supposedly already learned:

- **Error analysis (Step 5).** Before offering any verbal read of where
  a model goes wrong, display the errors — confusion matrix, error-type
  cross-tabs — first. Two specific failures here: correct-vs-incorrect
  is not the same as false-negative-vs-false-positive, and
  **collapsing FN and FP together can hide real, opposite-signed
  patterns** (a first pass grouped by plain correctness and found weak
  differences everywhere; splitting by actual error type on the *same*
  data revealed a sharp pattern invisible in the collapsed view). And
  numbers described in chat are not the same as a chart in the
  notebook — a first pass narrated `.value_counts()`/`.groupby().mean()`
  output without plotting anything, and the student had to ask directly
  whether it had been displayed at all.
- **Hyperparameter sensitivity (Step 6) — the relapse.** After the
  error-analysis fix above was already written into this file, a later
  hyperparameter-sensitivity comparison in the *same* session was
  computed and reported as printed group-means dictionaries, never
  charted — the identical mistake, one step later, that the narrower
  fix didn't prevent because it was scoped to "error analysis"
  specifically rather than "quantitative comparisons" generally. The
  student didn't catch this one; it surfaced only in a later
  retrospective review. Lesson: when a display-discipline fix gets
  written down, write the general principle, not just the specific
  instance that prompted it — a narrowly-scoped fix will not
  self-generalize to the next analogous situation.

## Keep the baseline in view, periodically, not just once in Step 1

Step 1's naive baselines are easy to lose sight of deep into modeling —
**proactively resurface the current-best-vs-baseline comparison at
natural checkpoints** (end of Step 5, after Step 6 tuning, and
especially right before the test set gets touched), not only when the
student asks. If the gap over the honest baseline isn't clearing, or
isn't statistically real (same paired-comparison discipline as any
other result in this skill), that's a signal to question the whole
approach — worth surfacing as its own checkpoint, not a footnote from
Step 1. Prompted by the student directly in the reference session,
right before the test-set touch — the resulting check (a genuinely
significant multi-point gap, p<0.01) was reassuring, but the point is
the check itself should be a standing habit, not contingent on being
asked.

## When models tie on the primary metric, name the other diagnostics that exist

A paired significance test finding two or more models statistically
indistinguishable (a real, recurring outcome — see `ml-recipe`'s own
notes on close CV races) is a specific, recognizable trigger point:
**proactively name that other diagnostics exist as potential
tie-breakers**, rather than silently picking a winner by point estimate
or waiting to be asked. Missed twice in the reference session (Step 5's
GB/LR tie, Step 6's top-5-tuned-configs tie) before the student raised
it directly. Worth mentioning at that trigger:

- **Log-loss / Brier score** — proper scoring rules that grade the
  probability, not just the thresholded decision.
- **ROC-AUC** — ranking quality across all thresholds, not just the one
  accuracy was computed at.
- **Calibration** — does a 66%-predicted bin actually contain ~66%
  positives (`sklearn.calibration.calibration_curve`)? The most
  important of these three to check, and a prerequisite for the next
  one to mean anything.
- **Confidence/sharpness of predicted probabilities** — but flag this
  one with its own caveat, don't just offer it neutrally: a model
  producing confident (near-0/1) probabilities is only a good sign if
  it's *also* well-calibrated. Confidently wrong is worse than honestly
  uncertain — sharpness is a valid tiebreaker only among comparably
  calibrated models, never a virtue on its own. An overfit model will
  readily produce falsely confident probabilities.

As with the hypothesis-formulation lens (Protocol step 2) — raise these
as available options at the trigger point, then let the student decide
which (if any) to pursue. Don't compute all of them unprompted; naming
that they exist is the proactive part, choosing which to run is still
the student's call.

## Watch for the subtle CV-leak trap, and flag it out loud

When Step 4 exploration mutates a working DataFrame directly with plain
pandas (e.g. filling missing values using a statistic computed from the
*whole* training set, for convenience) — normal and fine for EDA — there
is a real risk later, in Step 5/6, of that already-mutated frame getting
fed into cross-validation instead of raw data routed through the real
`fit`/`transform` pipeline. Each CV fold's held-out portion would then
have quietly influenced its own filled values via the shared statistic:
a genuine leak, entirely contained within the training set, easy to
miss since it never touches the actual test set. (See `ml-recipe`'s
"A subtler leak" section for the general mechanism.)

**When this pattern is spotted — whether it's about to happen or
already has — name it out loud to the student as its own teaching
moment**, the same way a wrong hypothesis gets sat with rather than
quietly corrected. Don't just silently fix it and move on. It's fine to
let the student choose to proceed pragmatically once they understand
the risk (e.g. "we'll allow it for simplicity here") — the goal is
sensitizing them to recognize this pattern themselves later, not
insisting every session rebuild everything leak-proof from the first
line of exploration.

## Session mechanics

- Build the notebook incrementally, cell by cell, as the dialogue
  unfolds — don't pre-generate the whole notebook and walk through it,
  since the content depends on what the student actually proposes.
- Keep a visible thread of the checklist step currently in play (e.g. a
  markdown cell per step transition) so the student can track where they
  are in the recipe across a long session.
- If picking this up mid-notebook after a break, briefly recap the
  current step and the last open decision before continuing — don't
  silently resume as if no time passed.
- **A thorough session eventually outgrows the `Read`/`NotebookEdit`
  tools' size limit** — `NotebookEdit` requires a fresh `Read` before
  every write, and a long enough notebook (with real output — plots,
  wide tables) makes that `Read` exceed the context/token cap, blocking
  further edits entirely, even with small `offset`/`limit`. When this
  happens, switch to editing the `.ipynb` directly via `nbformat`
  (Python, run through Bash) — append/modify cells and `nbformat.write`
  — which has no such read-first requirement. Hit exactly this wall
  building the reference notebook.
- **Charts need to be genuinely readable, not just present.** Set a
  larger-than-default theme once, early (e.g.
  `sns.set_theme(style="whitegrid", font_scale=1.15)` and a `figure.figsize`
  floor around `(10, 6)`), and size multi-panel figures generously
  (`catplot`/facet grids especially — `height=4` reads as cramped with
  several columns; `5-6` is more legible). Caught live in the reference
  session: default sizes rendered too small to read comfortably.
- **The notebook is edited on disk and executed out-of-band (via
  `nbconvert`), not through VSCode's live kernel — the editor doesn't
  always notice the file changed underneath it.** After pushing updates,
  remind the student how to force a refresh (VSCode: `Cmd/Ctrl+Shift+P` →
  "Revert File", or close/reopen the tab) — **by default, every time**,
  since a student silently looking at stale output is worse than a
  repeated one-line reminder. Ask early whether they'd prefer less
  frequent reminders (e.g. only after a batch of changes) or none at all,
  and honor whatever they pick — don't keep repeating a reminder they've
  explicitly turned off.
- **Maintain a running "Ideas to Revisit" section** (near the top of the
  notebook, so it stays visible) for anything deliberately left
  unresolved to keep moving forward — a feature not yet explored, an
  encoding decision deferred to a later step, a hypothesis that needs a
  test not yet available. Making forward progress means leaving steps
  before every possibility is exhausted; that's fine as long as what got
  skipped is tracked, not silently dropped. Update it at natural
  checkpoints (end of a checklist step, or whenever a new open thread
  surfaces): move items to "resolved" with the evidence that resolved
  them, or leave them open and carry them forward. Split "open" from
  "tentatively resolved, pending a specific stronger test" when that
  distinction is real — a hypothesis supported by EDA isn't the same as
  one confirmed by the actual model-based test that would settle it.
===== END FILE: ~/.claude/skills/ml-recipe-student/SKILL.md =====

