# What to give your friend

Give them either the **`ml-recipe-dist/`** directory or **`ml-recipe-dist.tar.gz`**
(same contents, archived). They open `INSTALL.md` inside it and pick one path:

- **Option A — one command:**
  ```bash
  mkdir -p ~/.claude/skills && cp -r skills/ml-recipe skills/ml-recipe-student ~/.claude/skills/
  ```

- **Option B — let Claude do it:** paste all of `INSTALL-PROMPT.md` into their
  Claude Code. It's self-contained (the skill text is embedded) and writes both
  files itself.

Then: start a new Claude Code session → run `/skills` to confirm `ml-recipe` and
`ml-recipe-student` are both listed.

Trigger prompts and the full limitations table are in `INSTALL.md` / `README.md`
inside the bundle. Short version:

- **Claude builds it:** "Use the ml-recipe skill to build a Jupyter notebook that
  works the \<X\> supervised-learning problem end to end."
- **Claude mentors you:** "Use the ml-recipe-student skill to guide me through an
  end-to-end ML notebook for \<X\>. Treat me as a student: I lead each significant
  decision, you execute and then critique, we decide together before moving on."

## Regenerating the bundle after editing a skill

From `~/claude/ml-recipe-skills-dist/`:

```bash
./build-dist.sh          # rebuild ml-recipe-dist/ and ml-recipe-dist.tar.gz
./build-dist.sh check    # exit 1 if the bundle is stale vs ~/.claude/skills
```

Editable prose is in `src/`; everything under `ml-recipe-dist/` is generated —
don't hand-edit it.
